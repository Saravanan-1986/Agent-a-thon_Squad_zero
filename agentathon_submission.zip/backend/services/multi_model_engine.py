"""
Multi-Model Engine (LLM Orchestration & Auto-Detection)

The Knowledge Debt Engine uses OpenRouter as its LLM gateway.
For the current demo, OpenRouter routes requests to Google's
Gemini 2.0 Flash Lite model (`google/gemini-2.0-flash-lite-001`).
The application receives a structured LLM evaluation, while
deterministic backend rules enforce the verification threshold
and state transition.

CURRENT DEMO EXECUTION PATH:
OpenRouter API key → OpenRouter → Google Gemini 2.0 Flash Lite model

OPTIONAL ALTERNATIVE:
Google Gemini API key → Google Gemini REST API directly
"""

import os
import json
import logging
from typing import Any, Dict, List, Optional
import httpx
from dotenv import load_dotenv

load_dotenv()

logger = logging.getLogger("backend.services.multi_model_engine")

GEMINI_URL_TEMPLATE = "https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent?key={key}"
DEFAULT_GEMINI_MODEL = os.getenv("GEMINI_MODEL", "gemini-flash-lite-latest")

OPENROUTER_URL = "https://openrouter.ai/api/v1/chat/completions"
DEFAULT_OPENROUTER_MODEL = os.getenv("SLICE_FALLBACK_MODEL", os.getenv("OPENROUTER_MODEL", "google/gemini-2.5-flash-lite"))


class MultiModelEngine:
    """
    Unified multi-model client with automatic provider detection, token budgeting,
    and deterministic offline evaluation fallback.
    """

    def __init__(self):
        self.gemini_key = os.getenv("GEMINI_API_KEY", "").strip()
        self.gemini_model = os.getenv("GEMINI_MODEL", DEFAULT_GEMINI_MODEL)
        self.openrouter_key = os.getenv("OPENROUTER_API_KEY", "").strip()
        self.openrouter_model = os.getenv("SLICE_FALLBACK_MODEL", os.getenv("OPENROUTER_MODEL", DEFAULT_OPENROUTER_MODEL))
        self.cumulative_prompt_tokens = 0
        self.cumulative_completion_tokens = 0
        self.cumulative_total_tokens = 0
        self.total_calls_count = 0
        self.last_usage = None

    def record_usage(self, usage_dict: Optional[Dict[str, Any]]):
        if usage_dict and isinstance(usage_dict, dict):
            p_tok = int(usage_dict.get("prompt_tokens", 0))
            c_tok = int(usage_dict.get("completion_tokens", 0))
            t_tok = int(usage_dict.get("total_tokens", p_tok + c_tok))
            self.cumulative_prompt_tokens += p_tok
            self.cumulative_completion_tokens += c_tok
            self.cumulative_total_tokens += t_tok
            self.total_calls_count += 1
            self.last_usage = {
                "prompt_tokens": p_tok,
                "completion_tokens": c_tok,
                "total_tokens": t_tok
            }
        else:
            self.total_calls_count += 1

    def get_budget_status(self) -> Dict[str, Any]:
        """
        Queries OpenRouter key-info endpoint (https://openrouter.ai/api/v1/auth/key)
        for live usage and limit. If unavailable, returns 'unknown' without hardcoding prices.
        """
        if self.openrouter_key:
            try:
                headers = {"Authorization": f"Bearer {self.openrouter_key}"}
                with httpx.Client(timeout=5.0) as client:
                    resp = client.get("https://openrouter.ai/api/v1/auth/key", headers=headers)
                    if resp.status_code == 200:
                        key_data = resp.json().get("data", {})
                        usage_usd = key_data.get("usage")
                        limit_usd = key_data.get("limit") or 10.00
                        if usage_usd is not None:
                            spent = round(float(usage_usd), 6)
                            remaining = round(float(limit_usd) - spent, 6)
                            return {
                                "budget_cap": float(limit_usd),
                                "total_calls": self.total_calls_count,
                                "total_tokens": self.cumulative_total_tokens if self.cumulative_total_tokens > 0 else "unknown",
                                "spent_dollars": spent,
                                "remaining_dollars": remaining,
                                "last_call_usage": self.last_usage or "unknown"
                            }
            except Exception as e:
                logger.warning("Could not fetch OpenRouter key info: %s", e)

        return {
            "budget_cap": 10.00,
            "total_calls": self.total_calls_count,
            "total_tokens": self.cumulative_total_tokens if self.cumulative_total_tokens > 0 else "unknown",
            "spent_dollars": "unknown",
            "remaining_dollars": "unknown",
            "last_call_usage": self.last_usage or "unknown"
        }

    def is_configured(self) -> bool:
        """Returns True if a real LLM API key (Gemini or OpenRouter) is configured."""
        return bool(self.gemini_key or self.openrouter_key)

    def get_active_provider(self) -> str:
        if self.gemini_key:
            return "gemini"
        if self.openrouter_key:
            return "openrouter"
        return "deterministic_fallback"

    def get_status(self) -> Dict[str, Any]:
        provider = self.get_active_provider()
        model = self.gemini_model if provider == "gemini" else self.openrouter_model if provider == "openrouter" else "local_deterministic"
        mode_label = "REAL" if self.is_configured() else "OFFLINE"

        if provider == "openrouter":
            provider_label = "OpenRouter"
            model_name = "Google Gemini 2.0 Flash Lite" if self.openrouter_model == "google/gemini-2.0-flash-lite-001" else self.openrouter_model
            api_endpoint = OPENROUTER_URL
            display_badge = "OpenRouter → Gemini 2.0 Flash Lite (REAL)"
        elif provider == "gemini":
            provider_label = "Google Gemini API (Direct)"
            model_name = self.gemini_model
            api_endpoint = GEMINI_URL_TEMPLATE
            display_badge = "Gemini (REAL)"
        else:
            provider_label = "Deterministic Fallback"
            model_name = "Deterministic Engine"
            api_endpoint = "N/A"
            display_badge = "deterministic_fallback (OFFLINE)"

        return {
            "provider": provider_label,
            "active_provider": provider,
            "active_provider_label": provider_label,
            "model": model_name,
            "active_model": model_name,
            "model_id": model,
            "api": provider_label,
            "api_endpoint": api_endpoint,
            "mode": mode_label,
            "display_badge": display_badge,
            "gemini_available": bool(self.gemini_key),
            "openrouter_available": bool(self.openrouter_key),
            "fallback_enabled": True,
            "budget": self.get_budget_status(),
            "architecture_note": (
                "The Knowledge Debt Engine uses OpenRouter as its LLM gateway. "
                "For the current demo, OpenRouter routes requests to Google's "
                "Gemini 2.0 Flash Lite model (`google/gemini-2.0-flash-lite-001`). "
                "The application receives a structured LLM evaluation, while "
                "deterministic backend rules enforce the verification threshold "
                "and state transition."
            ),
            "core_principle": "LLM proposes. Evidence decides."
        }


    def generate_json(
        self,
        system_prompt: str,
        user_prompt: str,
        max_tokens: int = 1200,
        temperature: float = 0.2
    ) -> Optional[Dict[str, Any]]:
        """
        Generates structured JSON using the active model provider with fallback chain:
        Gemini -> OpenRouter -> None (caller uses deterministic fallback template).
        Includes 1-retry on JSON syntax error and explicit HTTP 402/429 handling.
        """
        is_test_mode = os.getenv("KNOWLEDGE_DEBT_TEST_MODE", "").lower() in ["true", "1", "yes"]
        is_replay_mode = os.getenv("KNOWLEDGE_DEBT_REPLAY_MODE", "").lower() in ["true", "1", "yes"]
        if is_test_mode or is_replay_mode:
            return None

        # Helper function for HTTP 402 / 429 inspection & JSON parsing with fallback model / token reduction
        def _execute_openrouter_call(
            sys_p: str,
            usr_p: str,
            target_model: str,
            tok_limit: int,
            is_json_retry: bool = False,
            is_402_retry: bool = False,
            is_429_fallback: bool = False
        ) -> Optional[Dict[str, Any]]:
            headers = {
                "Authorization": f"Bearer {self.openrouter_key}",
                "Content-Type": "application/json"
            }
            payload = {
                "model": target_model,
                "messages": [
                    {"role": "system", "content": sys_p},
                    {"role": "user", "content": usr_p}
                ],
                "response_format": {"type": "json_object"},
                "temperature": temperature,
                "max_tokens": tok_limit
            }
            try:
                with httpx.Client(timeout=15.0) as client:
                    resp = client.post(OPENROUTER_URL, headers=headers, json=payload)
                    if resp.status_code == 200:
                        resp_data = resp.json()
                        self.record_usage(resp_data.get("usage"))
                        raw_text = resp_data["choices"][0]["message"]["content"] or ""
                        raw_text = self._strip_markdown_code_block(raw_text)
                        try:
                            parsed = json.loads(raw_text)
                            logger.info("OpenRouter generated structured JSON (model=%s, 402_retry=%s, 429_fallback=%s)", target_model, is_402_retry, is_429_fallback)
                            return parsed
                        except json.JSONDecodeError as json_err:
                            if not is_json_retry:
                                logger.warning("JSON parse failure on 1st attempt: %s. Performing 1-retry with strict JSON constraint prompt.", json_err)
                                strict_sys = sys_p + "\n\nCRITICAL: Output ONLY valid JSON syntax. No markdown code blocks."
                                return _execute_openrouter_call(strict_sys, usr_p, target_model, tok_limit, is_json_retry=True, is_402_retry=is_402_retry, is_429_fallback=is_429_fallback)
                            else:
                                logger.error("JSON parse failure on 2nd attempt: %s. Falling back to deterministic engine.", json_err)
                                return None

                    elif resp.status_code == 429:
                        fallback_llm = os.getenv("SLICE_FALLBACK_MODEL", "google/gemini-2.5-flash-lite")
                        if not is_429_fallback and fallback_llm != target_model:
                            logger.warning("Primary model %s hit HTTP 429 Rate Limit. Trying fallback LLM '%s' before local engine.", target_model, fallback_llm)
                            return _execute_openrouter_call(sys_p, usr_p, fallback_llm, tok_limit, is_429_fallback=True)
                        else:
                            logger.warning("HTTP 429 Rate Limit encountered on fallback LLM %s. Switching to local deterministic fallback engine.", target_model)
                            return None

                    elif resp.status_code == 402:
                        if not is_402_retry:
                            reduced_tokens = max(150, tok_limit // 2)
                            logger.warning("OpenRouter HTTP 402 Out of Credit on model %s. Retrying once with smaller max_tokens (%d -> %d).", target_model, tok_limit, reduced_tokens)
                            return _execute_openrouter_call(sys_p, usr_p, target_model, reduced_tokens, is_402_retry=True)
                        else:
                            logger.error("Payment Required / Out of Credit ($10.00 hard limit reached). System automatically switched to offline deterministic fallback engine.")
                            return None
                    else:
                        logger.warning("OpenRouter HTTP %s on model %s: %s", resp.status_code, target_model, resp.text[:150])
            except httpx.TimeoutException:
                logger.warning("OpenRouter HTTP request timed out (15.0s limit). Reverting to deterministic fallback.")
            except Exception as e:
                logger.warning("OpenRouter API call failed on model %s: %s. Reverting to deterministic fallback.", target_model, e)
            return None

        # 1. Primary: Google Gemini
        if self.gemini_key:
            try:
                url = GEMINI_URL_TEMPLATE.format(model=self.gemini_model, key=self.gemini_key)
                payload = {
                    "contents": [
                        {"parts": [{"text": f"{system_prompt}\n\n{user_prompt}"}]}
                    ],
                    "generationConfig": {
                        "temperature": temperature,
                        "maxOutputTokens": max_tokens,
                        "responseMimeType": "application/json"
                    }
                }
                with httpx.Client(timeout=12.0) as client:
                    resp = client.post(url, json=payload)
                    if resp.status_code == 200:
                        data = resp.json()
                        candidates = data.get("candidates", [])
                        if candidates and "content" in candidates[0]:
                            raw_text = candidates[0]["content"]["parts"][0]["text"].strip()
                            parsed = json.loads(raw_text)
                            logger.info("Gemini generated structured JSON (model=%s)", self.gemini_model)
                            self.record_usage(data.get("usageMetadata"))
                            return parsed
                    elif resp.status_code in (402, 429):
                        logger.warning("Gemini HTTP %s encountered. Trying OpenRouter secondary provider.", resp.status_code)
                    else:
                        logger.warning("Gemini HTTP %s: %s", resp.status_code, resp.text[:150])
            except Exception as e:
                logger.warning("Gemini API call failed: %s. Trying secondary provider.", e)

        # 2. Secondary: OpenRouter
        if self.openrouter_key:
            return _execute_openrouter_call(system_prompt, user_prompt, self.openrouter_model, max_tokens)

        return None

    def generate_text(
        self,
        system_prompt: str,
        user_prompt: str,
        max_tokens: int = 400,
        temperature: float = 0.2
    ) -> Optional[str]:
        """
        Generates freeform text using the active model provider with fallback chain.
        """
        is_test_mode = os.getenv("KNOWLEDGE_DEBT_TEST_MODE", "").lower() in ["true", "1", "yes"]
        if is_test_mode:
            return None

        # 1. Primary: Google Gemini
        if self.gemini_key:
            try:
                url = GEMINI_URL_TEMPLATE.format(model=self.gemini_model, key=self.gemini_key)
                payload = {
                    "contents": [
                        {"parts": [{"text": f"{system_prompt}\n\n{user_prompt}"}]}
                    ],
                    "generationConfig": {
                        "temperature": temperature,
                        "maxOutputTokens": max_tokens
                    }
                }
                with httpx.Client(timeout=10.0) as client:
                    resp = client.post(url, json=payload)
                    if resp.status_code == 200:
                        raw_text = resp.json()["candidates"][0]["content"]["parts"][0]["text"].strip()
                        return raw_text
            except Exception as e:
                logger.warning("Gemini text generation failed: %s", e)

        # 2. Secondary: OpenRouter
        if self.openrouter_key:
            try:
                headers = {
                    "Authorization": f"Bearer {self.openrouter_key}",
                    "Content-Type": "application/json"
                }
                payload = {
                    "model": self.openrouter_model,
                    "messages": [
                        {"role": "system", "content": system_prompt},
                        {"role": "user", "content": user_prompt}
                    ],
                    "temperature": temperature,
                    "max_tokens": max_tokens
                }
                with httpx.Client(timeout=12.0) as client:
                    resp = client.post(OPENROUTER_URL, headers=headers, json=payload)
                    if resp.status_code == 200:
                        raw_text = resp.json()["choices"][0]["message"]["content"] or ""
                        return raw_text.strip()
            except Exception as e:
                logger.warning("OpenRouter text generation failed: %s", e)

        return None

    @staticmethod
    def _strip_markdown_code_block(text: str) -> str:
        text = text.strip()
        if text.startswith("```"):
            lines = text.splitlines()
            if lines[0].startswith("```"):
                lines = lines[1:]
            if lines and lines[-1].startswith("```"):
                lines = lines[:-1]
            text = "\n".join(lines).strip()
        return text


# Global singleton instance
engine = MultiModelEngine()
